﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class Form1

    Dim newAccess As Accesso
    Dim newExcel As Excelo
    Dim myApplication As New Excel.Application
    Dim myWorkBook As Excel.Workbook
    Dim myWorkSheet As Excel.Worksheet

    Dim con As New OleDbConnection

    Dim connString As String

    'Dim getDB = newAccess.GetDatabase(Label1.Text, TextBox.Text)


    Private Sub OpenButton_Click(sender As Object, e As EventArgs) Handles OpenButton.Click
        OpenFileDialog1.ShowDialog()
        Label1.Text = OpenFileDialog1.FileName
        connString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=C:\Users\Cameron\Desktop\Access2010DB"
        ' newExcel.openSaveAndPopulate(TextBox.Text, True, getDB)


    End Sub

    Private Sub DataGridView1_CellContentClick(sender As Object, e As DataGridViewCellEventArgs) Handles DataGridView1.CellContentClick
        'newAccess.GetDatabase(Label1.Text, TextBox.Text)



    End Sub

    Private Sub SaveButton_Click(sender As Object, e As EventArgs) Handles SaveButton.Click

    End Sub

    Private Sub TextBox_TextChanged(sender As Object, e As EventArgs) Handles TextBox.TextChanged

    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        con.ConnectionString = connString
        con.Open()

        datagridShow()
    End Sub

    Private Sub datagridShow()
        Dim ds As New DataSet
        Dim dt As New DataTable
        ds.Tables.Add(dt)
        Dim da As New OleDbDataAdapter
        da = New OleDbDataAdapter("select * from Authors", con)
        da.Fill(dt)
        DataGridView1.DataSource = dt.DefaultView
        con.Close()

    End Sub
End Class
