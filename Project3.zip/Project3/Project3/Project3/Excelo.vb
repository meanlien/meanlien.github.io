﻿Imports Excel = Microsoft.Office.Interop.Excel

Public Class Excelo
    Dim myApplication As Excel.Application

    Dim myWorkBook As Excel.Workbook

    Dim myWorkSheet As Excel.Worksheet

    Sub openSaveAndPopulate(MyFileName As String, exists As Boolean, DGVmyView As DataGridView)

        CheckifReal(MyFileName, exists)

        Poplulate(DGVmyView)

        SaveExcelFile(MyFileName, exists)

    End Sub



    Private Sub CheckifReal(MyFileName As String, exists As Boolean)

        On Error Resume Next

        'create Excel object

        myApplication = CreateObject("Excel.Application")

        'if file exists, place file name in FileCheck

        If exists Then

            'Workbook exists, open it

            myWorkBook = myApplication.Workbooks.Open(MyFileName)

            myWorkSheet = myWorkBook.Worksheets(1)

        Else

            'Workbook doesn't exist, create new workbook

            myWorkBook = myApplication.Workbooks.Add

            myWorkSheet = myWorkBook.Worksheets(1)

        End If

    End Sub

    Private Sub Poplulate(DGVmyView As DataGridView)

        'do this on your own

    End Sub

    Private Sub SaveExcelFile(MyFileName As String, exists As Boolean)

        If exists Then

            'Save existing workbook

            myWorkBook.Save()

        Else

            'Save new workbook

            myWorkBook.SaveAs(MyFileName)

        End If

        'Close Excel

        myWorkBook.Close(SaveChanges:=False)

        myApplication.Quit()

        myApplication = Nothing

        myWorkBook = Nothing

        myWorkSheet = Nothing

    End Sub
End Class
