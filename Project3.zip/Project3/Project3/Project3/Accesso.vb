﻿Imports System.Data.OleDb

Public Class Accesso


    Dim MyConnection As OleDbConnection

    Dim MyDataAdapter As OleDbDataAdapter

    Dim myDataSet As DataSet

    Dim Mytables As DataTableCollection

    Dim mySource As New BindingSource



    Function GetDatabase(Address As String, SetName As String) As DataView

        MyConnection = New OleDbConnection

        MyConnection.ConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0; Data Source=" & Address

        myDataSet = New DataSet

        Mytables = myDataSet.Tables

        Dim Comand As String = "Select * from [" & SetName & "]"

        MyDataAdapter = New OleDbDataAdapter(Comand, MyConnection)

        MyDataAdapter.Fill(myDataSet, SetName)

        Dim ViewofDatabase As New DataView(Mytables(0))

        Return ViewofDatabase

    End Function
End Class
